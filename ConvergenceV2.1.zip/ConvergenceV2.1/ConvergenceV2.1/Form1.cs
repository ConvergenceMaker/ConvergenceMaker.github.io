﻿using KrnlAPI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConvergenceV2._1
{
    public partial class Form1 : Form
    {
        KrnlApi krnlApi = new KrnlApi();
        private Point lastPoint;

        public Form1()
        {
            InitializeComponent();
            krnlApi.Initialize();
        }

        private void fastColoredTextBox1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (!krnlApi.IsInitialized())
            {
                krnlApi.Initialize();
            } else
            {

            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
{
	this.Left += e.X - lastPoint.X;
	this.Top += e.Y - lastPoint.Y;
}
        }
    }
}
